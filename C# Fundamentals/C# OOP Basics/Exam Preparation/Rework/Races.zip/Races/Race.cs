﻿using System.Collections.Generic;

public abstract class Race
{
    private int lenght;
    private string route;
    private int prizePool;
    private List<Car> participants;

    public Race(int lenght, string route, int prizePool)
    {
        this.lenght = lenght;
        this.route = route;
        this.prizePool = prizePool;
        this.participants = new List<Car>();
    }

    public void AddParticipant(Car car)
    {
        this.participants.Add(car);
    }

    public int PrizePool { get => this.prizePool; }

    public IReadOnlyCollection<Car> Participants
    {
        get => this.participants as IReadOnlyCollection<Car>;
    }

    public virtual List<string> StartRace()
    {
        return new List<string>()
        {
            $"{this.route} - {this.lenght}"
        };
    }
}

