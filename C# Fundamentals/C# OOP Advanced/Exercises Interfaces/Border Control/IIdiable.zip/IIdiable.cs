﻿public interface IIdiable
{
    string Id { get; }
}
