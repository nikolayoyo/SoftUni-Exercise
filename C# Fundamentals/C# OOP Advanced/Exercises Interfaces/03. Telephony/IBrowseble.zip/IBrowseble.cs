﻿public interface IBrowseble
    {
        string Browse(string url);
    }
