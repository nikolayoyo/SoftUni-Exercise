﻿internal interface IBirthable
{
    string Birthdate { get; }
}