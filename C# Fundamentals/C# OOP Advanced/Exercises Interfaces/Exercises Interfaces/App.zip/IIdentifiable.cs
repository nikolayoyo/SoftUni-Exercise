﻿internal interface IIdentifiable
{
    string Id { get; }
}