﻿public interface ICar
{
    string Model { get; }
    string Brakes();
    string GasPedal();
    string DriverName { get; }
}

