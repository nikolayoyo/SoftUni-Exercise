﻿public class BarbarianConstants
    {
        public static readonly long Strength = 90;
        public static readonly long Agility = 25;
        public static readonly long Intelligence = 10;
        public static readonly long HitPoints = 350;
        public static readonly long Damage = 150;
    }
