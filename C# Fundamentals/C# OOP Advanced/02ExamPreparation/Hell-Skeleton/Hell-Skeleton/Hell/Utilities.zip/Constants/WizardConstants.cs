﻿public class WizardConstants
    {
        public static readonly long Strength = 25;
        public static readonly long Agility = 25;
        public static readonly long Intelligence = 100;
        public static readonly long HitPoints = 100;
        public static readonly long Damage = 250;
    }
