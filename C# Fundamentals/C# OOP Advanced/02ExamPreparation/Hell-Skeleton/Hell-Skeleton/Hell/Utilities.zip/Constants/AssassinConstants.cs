﻿public class AssassinConstants
{
    public static readonly long Strength = 25;
    public static readonly long Agility = 100;
    public static readonly long Intelligence = 15;
    public static readonly long HitPoints = 150;
    public static readonly long Damage = 300;
}
