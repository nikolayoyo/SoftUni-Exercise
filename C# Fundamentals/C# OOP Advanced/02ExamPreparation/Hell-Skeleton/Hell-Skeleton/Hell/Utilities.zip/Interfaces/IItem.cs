﻿public interface IItem
    {
        string Name { get; }

        long StrengthBonus { get; }

        long IntelligenceBonus { get; }

        long AgilityBonus { get; }

        long HitPointsBonus { get; }

        long DamageBonus { get; }

    }
